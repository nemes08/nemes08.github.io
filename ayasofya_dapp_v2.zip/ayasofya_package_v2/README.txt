Ayasofya Charity DApp Package
Files:
- index.html
- stil.css
- script.js
- pi.js (demo stub; replace with real pi.js if you have)
- resimler/logo.svg
- resimler/ayasofya-hero.svg

Upload instructions:
1. Go to your repository nemes08.github.io on GitHub.
2. Use 'Add file' -> 'Upload files' and drag the contents of this ZIP preserving folder structure.
3. Commit changes. Wait ~30s.
4. Open https://nemes08.github.io/?v=2 to bypass cache.
